## [1.1.2] 2019-03-05
### Updated license
- added license inside App.js

## [1.1.1] 2019-02-18
### Updated dependencies
- `galio-framework@0.4.3` to `galio-framework@0.4.4`

## [1.1.0] 2019-02-18
### Added files
- Added .gitignore file
### Updated dependencies
- `expo@31.0.2` to `expo@32.0.0`
- `galio-framework@0.4.2` to `galio-framework@0.4.3`
- `react-native SDK@31.0.0` to `react-native SDK@32.0.0`

## [1.0.0] 2019-02-06
### Initial Release
