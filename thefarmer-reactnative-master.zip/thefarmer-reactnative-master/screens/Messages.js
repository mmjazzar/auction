import React from 'react';
import { StyleSheet, FlatList, View, Platform, Image, TouchableOpacity } from "react-native";
import { Block, Text, theme } from "galio-framework";

export default class Messages extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      hasMessages: false,
    };
  }

  openMessage(key) {
    // this.props.navigation.navigate('Chat', { messageKey: key });
  }

  renderMessages() {
    return (
      <View style={styles.container_2}>
        <FlatList
          data={[
            { key: 'عبدالرحمن محسن' },
            { key: 'هاني علي' },
            { key: 'يوسف حسام' },
            { key: 'احمد سعيد' },
          ]}
          renderItem={({ item }) => 
            <TouchableOpacity 
              style={styles.message} 
              onPress={() => this.openMessage(item.key)}
            >
              <Text style={styles.item}>{item.key}</Text>
            </TouchableOpacity>
          }
        />
      </View>
    );
  }

  renderNoMessages() {
    return (
      <Block style={styles.container} >
        <Text style={styles.title} >ليس لديك حاليًا أي رسائل</Text>
        <Image
            // source={{  uri: Images.Onboarding }}
            source={require('../assets/images/notmessage.png')}
            style={{ height: 150, width: 150 }}
        />
      </Block>
    );
  }

  render() {
    return (
      this.state.hasMessages ? this.renderMessages() : this.renderNoMessages()
    );
  }
}

const styles = StyleSheet.create({
  container: {
    paddingVertical: theme.SIZES.BASE / 3,
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  container_2: {
   flex: 1
  },
  message: {
    height: 52,
    borderWidth: 0.4,
    borderColor: '#ccc',
    backgroundColor: '#ffffff'
  },
  item: {
    padding: 20,
  },
  title: {
    paddingTop: theme.SIZES.BASE,
    paddingBottom: theme.SIZES.BASE / 2,
    fontSize: 16.0
  },
  rows: {
    height: theme.SIZES.BASE * 2,
    paddingHorizontal: theme.SIZES.BASE,
    marginBottom: theme.SIZES.BASE / 2,
  }
});
