import React, { Component } from 'react';
import { View, ScrollView, TouchableOpacity, ImageBackground, TextInput, StyleSheet, StatusBar, Dimensions, Platform, Image, ActivityIndicator, Alert } from 'react-native';
import { Block, Button, Text, theme } from 'galio-framework';

import { Input } from '../components/Input';

const { height, width } = Dimensions.get('screen');

import materialTheme from '../constants/Theme';

export default class Login extends React.Component {

  state = {
    email: '',
    password: '',
    authenticating: false,
    user: null,
    error: '',
  }

  render() {
    const { navigation } = this.props;

    return (
      <ImageBackground
        style={{ flex: 1 }}
        source={require('../assets/images/loginscreen.jpg')}
        //You can also set image from your project folder
        //require('./images/background_image.jpg')        //
        >
        {/* <View style={styles.MainContainer}> */}
            <ScrollView style={styles.container}>
                 <View style = {styles.contentWrap}>
                    <Text style={styles.title}>
                    تسجيل الدخول باستخدام حسابك الاجتماعي
                    </Text>
                    <View style={styles.buttonLoginWrap}>
                        <TouchableOpacity>
                           <Image style={styles.buttonLoginIcon} source={require('../assets/images/facebook.png')} />
                        </TouchableOpacity>

                        <TouchableOpacity>
                           <Image  style={styles.buttonLoginIcon} source={require('../assets/images/google-plus.png')} />
                        </TouchableOpacity>

                        {/* <TouchableOpacity>
                            <Image  style={styles.buttonLoginIcon} source={require('../../img/twitter.png')} />
                        </TouchableOpacity> */}
                    </View>
                    <View style={styles.emailSignUpWrap}>
                        <Text style={styles.title}>
                        أو
                        </Text>
                        <Input  
                            style={styles.textInput}
                            placeholder='أدخل بريدك الالكتروني...'
                            label='Email'
                            onChangeText={email => this.setState({ email })}
                            value={this.state.email}
                        />
                        <Input
                            style={styles.textInput}
                            placeholder='أدخل كلمة السر...'
                            label='Password'
                            onChangeText={password => this.setState({ password })}
                            value={this.state.password}
                        />

                        <Button
                            shadowless
                            style={styles.button}
                            color={materialTheme.COLORS.BUTTON_COLOR}
                            // onPress={() => navigation.navigate('Home')}>
                            onPress={() => navigation.navigate('App')}>
                            <Text style={styles.buttonLoginText}>تسجيل الدخول</Text>
                        </Button>
                        <TouchableOpacity 
                        // onPress={() => navigation.navigate('Pro')}
                        >
                                <Text style={[styles.subtitle,{marginTop: 15}]}> هل نسيت كلمة السر؟</Text>
                        </TouchableOpacity>
                    </View>
                    <View style={styles.line} />
                    <View style={{flex: 1}}>
                        <Text style={styles.subtitle}>ليس لديك حساب؟</Text>
                        <TouchableOpacity onPress={() => {}}>
                                <Text style={styles.subtitle}>سجل من هنا!</Text>
                        </TouchableOpacity>
                    </View>
                 </View>
                
            </ScrollView>
      </ImageBackground>
    )
  }
}

const styles = StyleSheet.create({
  container: {
      flex: 1,
      backgroundColor: 'rgba(52, 52, 52, 0.3)'
  },
  contentWrap: {
      flex: 1,
      padding: 15,
      marginTop: 50,
  },
  buttonLoginWrap: {
      flex: 1,
      flexDirection: 'row',
      alignItems: "center",
      justifyContent:'center'
  },
  buttonLoginIcon: {
      marginLeft: 12,
      marginRight: 12,
      width: 64,
      resizeMode: "contain"
  },
  buttonLogin: {
      marginTop: 20,
      fontSize: 16,
      fontWeight: '600',
      textAlign: 'center',
      padding: 10,
      backgroundColor: '#222222',
      color: '#ffffff'
  },
  title: {
      color: "#ffffff",
      fontSize: 21,
      fontWeight: '700',
      textAlign: 'center',
      marginTop: -15
  },
  line: {
      borderWidth:0.6,
      borderColor:"#ccc",
      flex: 1,
      marginTop: 20,
      marginBottom: 20
  },
  subtitle: {
      color: "#ffffff",
      fontSize: 18,
      textAlign: 'center',
      // textDecorationLine: "underline",
  },
  emailSignUpWrap: {
      flex: 1
  },
  inputGroup: {
      flex: 1,
      marginTop: 20,
      backgroundColor: '#ffffff'
  },
  textInput: {
      flex: 1,
      height: 50,
      paddingLeft: 20,
      paddingRight: 20,
      fontSize: 16,
      // fontWeight:'500',
      borderWidth: 1,
      borderColor:'#ccc',
      backgroundColor: '#ffffff'
  },
  button: {
    marginLeft: 20.0,
    width: width - theme.SIZES.BASE * 4,
    height: theme.SIZES.BASE * 3,
    shadowRadius: 0,
    shadowOpacity: 0,
    marginTop: 15
  },
  modalButton: {
    width: width - theme.SIZES.BASE * 6,
    height: theme.SIZES.BASE * 3,
    shadowRadius: 0,
    shadowOpacity: 0,
    marginTop: 15
  },
  MainContainer: {
    flex: 1,
    alignItems: 'center',
  },
  TextStyle: {
    color: '#0250a3',
    textAlign: 'center',
    fontSize: 30,
    marginTop: 10,
  },
  buttonLoginText: {
      fontSize: 16,
      fontWeight: '700',
      textAlign: 'center',
      color: '#ffffff'
  },
});

// export {Login}
