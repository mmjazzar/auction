export default [
  {
    title: 'Banks & Finance',
    image: 'https://www.investmentweek.co.uk/w-images/091ebf13-dd5e-4bad-8c52-21bf254ae560/1/bankofengland1a-580x358.jpg',
    horizontal: true,
  },
  {
    title: 'Diplomatic Missions',
    image: 'https://photos.smugmug.com/Oman-gallery/Oman-flag/i-RLvh54T/0/41b085f8/O/Oman%20Flag%20%289%29.jpg',
  },
  {
    title: 'Education',
    image: 'https://img.jakpost.net/c/2019/01/02/2019_01_02_62042_1546414179._large.jpg',
  },
  {
    title: 'Governmental',
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/Minnesota_State_Capitol_2017.jpg/1200px-Minnesota_State_Capitol_2017.jpg',
    horizontal: true,
  },
  {
    title: 'Health Medical',
    image: 'http://revolutionhealthaz.com/wp-content/uploads/2014/12/iStock_000022389329Large-2400x1600.jpg',
  },
  {
    title: 'Hotels',
    image: 'https://s-ec.bstatic.com/images/hotel/max1024x768/797/79726354.jpg',
  },
  {
    title: 'Petrol Stations',
    image: 'https://showme.co.za/secunda/files/2018/03/petrolstation.jpg',
  },
  {
    title: 'Postal Services',
    image: 'https://www.fedsmith.com/wp-content/uploads/2018/02/usps-mailboxes.jpg',
  },
  {
    title: 'Public Saftey',
    image: 'https://www.alertpss.com/wp-content/uploads/2016/07/meta-slider-html-overlay-computer-aided-dispatch-software-1472x708.jpg',
  },
  {
    title: 'Real Estate',
    image: 'https://www.nreionline.com/sites/nreionline.com/files/styles/article_featured_standard/public/commercial-real-estate-equity.jpg?itok=e2gD_HZK',
  },
  {
    title: 'Religious',
    image: 'https://media.linkonlineworld.com/img/large/2014/8/23/2014_8_23_22_1_23_560.jpg',
  },
  {
    title: 'Restaurants',
    image: 'https://tourismus.nuernberg.de/fileadmin/_processed_/8/2/csm_wuerzhaus_quelle_wuerzhaus_a3af3d0f0c.png',
  },
  {
    title: 'Shopping',
    image: 'https://www.sayidaty.net/sites/default/files/2018/11/25/4565636-1593559598.jpg',
  },
  {
    title: 'Travel & Tours',
    image: 'https://cdn.vortala.com/childsites/uploads/943/files/A-plane-Flying.jpg',
  },
];
