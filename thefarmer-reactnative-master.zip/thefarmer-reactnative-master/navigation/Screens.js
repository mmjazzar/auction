import React from 'react';
import { Easing, Animated, Platform, SafeAreaView, Button, View } from 'react-native';
import { createSwitchNavigator, createStackNavigator, createDrawerNavigator, createAppContainer, DrawerItems } from 'react-navigation';

import { Block, Text, theme } from "galio-framework";

import HomeScreen from '../screens/Home';
import OnboardingScreen from '../screens/Onboarding';
import MessagesScreen from '../screens/Messages';
import CameraScreen from '../screens/Camera';

import LoginScreen from '../screens/Login';

import Menu from './Menu';
import Header from '../components/Header';
import { Drawer } from '../components/';

const transitionConfig = (transitionProps, prevTransitionProps) => ({
  transitionSpec: {
    duration: 400,
    easing: Easing.out(Easing.poly(4)),
    timing: Animated.timing,
  },
  screenInterpolator: sceneProps => {
    const { layout, position, scene } = sceneProps;
    const thisSceneIndex = scene.index;
    const width = layout.initWidth;
    
    const scale = position.interpolate({
      inputRange: [thisSceneIndex - 1, thisSceneIndex, thisSceneIndex + 1],
      outputRange: [4, 1, 1]
    })
    const opacity = position.interpolate({
      inputRange: [thisSceneIndex - 1, thisSceneIndex, thisSceneIndex + 1],
      outputRange: [0, 1, 1],
    })
    const translateX = position.interpolate({
      inputRange: [thisSceneIndex - 1, thisSceneIndex],
      outputRange: [width, 0],
    })

    const scaleWithOpacity = { opacity }
    const screenName = "Search"

    if (screenName === transitionProps.scene.route.routeName ||
      (prevTransitionProps && screenName === prevTransitionProps.scene.route.routeName)) {
      return scaleWithOpacity;
    }
    return { transform: [{ translateX }] }
  }
})

const LoginStack = createStackNavigator({
  Login: {
    screen: LoginScreen,
    navigationOptions: ({ navigation }) => ({
      header: null,
    })
  },
}, {
  cardStyle: { backgroundColor: '#EEEEEE', },
  transitionConfig,
})

const onBoardingStack = createStackNavigator({
  Onboarding: {
    screen: OnboardingScreen,
    navigationOptions: ({ navigation }) => ({
        drawerLabel: () => {},
      header: null,
    })
  },
}, {
  cardStyle: { backgroundColor: '#EEEEEE', },
  transitionConfig,
})

const HomeStack = createStackNavigator({
  Home: {
    screen: HomeScreen,
    navigationOptions: ({navigation}) => ({
      header: <Header search title="الرئيسية" navigation={navigation} />,
    })
  },
  Messages: {
    screen: MessagesScreen,
    navigationOptions: ({navigation}) => ({
      header: <Header back search title="الرسائل" navigation={navigation} />,
    })
  },
  Camera: {
    screen: CameraScreen,
    navigationOptions: ({navigation}) => ({
      header: <Header back title="الكاميرا" navigation={navigation} />,
    })
  },
},
{ 
  cardStyle: { 
    backgroundColor: '#EEEEEE', //this is the backgroundColor for the app
  },
  transitionConfig,
});

const AppStack = createDrawerNavigator(
  {
    // Onboarding: {
    //   screen: OnboardingScreen,
    //   navigationOptions: {
    //     drawerLabel: () => {},
    //   },
    // },
    Dashboard: {
      screen: HomeStack,
      navigationOptions: (navOpt) => ({
        drawerLabel: ({focused}) => (
          <Drawer focused={focused} screen="Home" title="الرئيسية" />
        ),
      }),
    },
    Messages: {
      screen: MessagesScreen,
      navigationOptions: (navOpt) => ({
        drawerLabel: ({focused}) => (
          <Drawer focused={focused} screen="Messages" title="الرسائل" />
        ),
      }),
    },
  },
  Menu,
);

const AppSwitchNavigator = createSwitchNavigator(
  {
    App: AppStack,
    Home: HomeStack,
    Login: LoginStack,
    onBoarding: onBoardingStack
  },
  {
    initialRouteName: 'onBoarding',
  }
);

export default createAppContainer(AppSwitchNavigator);